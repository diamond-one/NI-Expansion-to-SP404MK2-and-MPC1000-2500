<script setup lang="ts">
import { onMounted, onUnmounted } from "vue";
import Icon from "./Icon.vue";
import { connect, scanPorts, store } from "../store";

/** How often the list is looked at again, so a device plugged in turns up by itself. */
const RESCAN_MS = 2000;
/** A device just plugged in needs a moment before it answers. */
const SETTLE_MS = 1000;

let timer: number | undefined;
let hadPorts = false;

async function rescan() {
  await scanPorts(true);
  const appeared = store.ports.length > 0 && !hadPorts;
  hadPorts = store.ports.length > 0;
  // Back after the cable came out: pick up where it left off, once per plug-in.
  if (appeared && store.reconnect && store.ports.length === 1 && !store.connecting) {
    await new Promise((r) => window.setTimeout(r, SETTLE_MS));
    if (store.reconnect && !store.connected) await connect(store.ports[0].name);
  }
  timer = window.setTimeout(rescan, RESCAN_MS);
}

onMounted(async () => {
  await scanPorts();
  // A port still listed straight after the cable came out is on its way out, so only a
  // port that shows up after this counts as the device coming back.
  hadPorts = store.ports.length > 0;
  timer = window.setTimeout(rescan, RESCAN_MS);
});
onUnmounted(() => window.clearTimeout(timer));
</script>

<template>
  <div class="connect">
    <div class="card panel">
      <div class="badge"><Icon name="usb" :size="22" /></div>
      <h1>Connect your SP-404MKII</h1>
      <p class="muted">Plug the sampler in over USB. SparkyMK2 finds it by its USB ID.</p>

      <div class="ports">
        <div v-for="p in store.ports" :key="p.name" class="port">
          <div>
            <div class="mono">{{ p.name }}</div>
            <div class="muted small">{{ p.product ?? "SP-404MKII" }}</div>
          </div>
          <button class="primary" :disabled="store.connecting" @click="connect(p.name)">
            <span v-if="store.connecting" class="spinner" />
            Connect
          </button>
        </div>
        <div v-if="!store.ports.length && !store.scanning" class="empty">
          No SP-404MKII found.
        </div>
      </div>

      <button :disabled="store.scanning" @click="scanPorts()">
        <span v-if="store.scanning" class="spinner" />
        <Icon v-else name="refresh" />
        Scan again
      </button>

      <ul class="hints muted">
        <li>Only one program can use the device at a time. Close the official app and the <span class="mono">sp404</span> tool first.</li>
        <li>The Debian, Fedora and Arch packages give you access to the device. With the AppImage or a source build, join the <span class="mono">uucp</span> group (Arch) or <span class="mono">dialout</span> (others) and log in again.</li>
      </ul>
    </div>
  </div>
</template>

<style scoped>
.connect {
  height: 100%;
  display: grid;
  place-items: center;
  padding: 24px;
  background: radial-gradient(1200px 500px at 50% -10%, rgba(255, 173, 51, 0.07), transparent);
}

.card {
  width: 460px;
  padding: 28px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 14px;
}

.badge {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  display: grid;
  place-items: center;
  color: var(--accent);
  background: var(--accent-soft);
  border: 1px solid var(--accent-line);
}

h1 {
  margin: 0;
  font-size: 20px;
  font-weight: 650;
}

p {
  margin: 0;
}

.ports {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.port {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 12px;
  border: 1px solid var(--line-strong);
  border-radius: 8px;
  background: var(--panel-2);
}

.empty {
  padding: 14px;
  border: 1px dashed var(--line-strong);
  border-radius: 8px;
  color: var(--muted);
  text-align: center;
}

.small {
  font-size: 12px;
}

.hints {
  margin: 4px 0 0;
  padding-left: 18px;
  font-size: 12.5px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
</style>
