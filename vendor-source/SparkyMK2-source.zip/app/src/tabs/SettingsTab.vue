<script setup lang="ts">
import { computed, reactive, ref, watch } from "vue";
import { getVersion } from "@tauri-apps/api/app";
import { open } from "@tauri-apps/plugin-dialog";
import EditableName from "../components/EditableName.vue";
import Icon from "../components/Icon.vue";
import { BANK_LETTERS, PROJECT_NAME_LEN, bpm, storage } from "../format";
import { backupProject, restoreBackup } from "../exporting";
import { api, errorText, setLoggingActive, type ClearParts, type LoggingState } from "../api";
import { clearProject, loadLibrary, renameProject, savePrefs, setGlobalParam, setLibraryDir, store } from "../store";

/** Shown so a bug report can say which version it is about. */
const version = ref("");
getVersion().then((v) => (version.value = v));

if (!store.library.loaded && !store.library.loading) loadLibrary();

async function chooseLibraryDir() {
  const dir = await open({ directory: true, title: "Keep the screen library in", defaultPath: store.library.dir || undefined });
  if (typeof dir === "string") await setLibraryDir(dir);
}

/** The diagnostic log, for sending in with a bug report. */
const logState = ref<LoggingState | null>(null);
const logError = ref("");
api.loggingState().then((s) => (logState.value = s));

async function toggleLogging(on: boolean) {
  logError.value = "";
  try {
    logState.value = await api.setLogging(on);
    setLoggingActive(logState.value.enabled);
  } catch (e) {
    logError.value = errorText(e);
  }
}

async function openLogFolder() {
  logError.value = "";
  try {
    await api.openLogFolder();
  } catch (e) {
    logError.value = errorText(e);
  }
}

const locked = () => store.status?.workingMode === 4;

const nothing: ClearParts = { samples: false, patterns: false, settings: false, screenImages: false, bank: null };
/** What Clear project will remove. */
const parts = reactive<ClearParts>({ ...nothing });
/** The project number, typed to confirm. */
const confirmText = ref("");
// Settings go through the device's Init "All", which takes samples and patterns with them.
watch(
  () => parts.settings,
  (on) => {
    if (on) Object.assign(parts, { samples: true, patterns: true });
  },
);
// A bank has samples and patterns of its own; settings and screen images are the project's.
watch(
  () => parts.bank,
  (bank) => {
    if (bank !== null) Object.assign(parts, { settings: false, screenImages: false });
  },
);
watch(
  () => store.status?.project,
  () => (confirmText.value = ""),
);
const canClear = computed(
  () =>
    (parts.samples || parts.patterns || parts.settings || parts.screenImages) &&
    confirmText.value.trim() === String(store.status?.project) &&
    !locked() &&
    store.pending === 0,
);

async function onClear() {
  const project = store.status?.project;
  if (!project || !canClear.value) return;
  if (await clearProject(project, { ...parts })) {
    Object.assign(parts, nothing);
    confirmText.value = "";
  }
}

/** Tempo text boxes, keyed by setting name, while being typed in. */
const tempoText = ref<Record<string, string>>({});
const volumeDraft = ref<Record<string, number>>({});

watch(
  () => store.status,
  () => {
    tempoText.value = {};
    volumeDraft.value = {};
  },
);

function tempoValue(name: string, hundredths: number) {
  return tempoText.value[name] ?? bpm(hundredths);
}

function commitTempo(name: string, current: number) {
  const text = tempoText.value[name];
  delete tempoText.value[name];
  if (text === undefined) return;
  const value = Math.round(parseFloat(text) * 100);
  if (Number.isFinite(value) && value >= 4000 && value <= 20000 && value !== current) setGlobalParam(name, value);
}

function commitVolume(letter: string, current: number) {
  const name = `bank-volume-${letter.toLowerCase()}`;
  const value = volumeDraft.value[name];
  if (value !== undefined && value !== current) setGlobalParam(name, value);
}
</script>

<template>
  <div v-if="store.status" class="settings">
    <section class="panel card">
      <div class="label">Project</div>
      <div class="project">
        <span class="num mono">{{ String(store.status.project).padStart(2, "0") }}</span>
        <EditableName
          class="pname"
          :value="store.projects[store.status.project - 1] ?? ''"
          placeholder="Unnamed"
          :max-length="PROJECT_NAME_LEN"
          :disabled="locked()"
          @commit="renameProject(store.status.project, $event)"
        />
      </div>
      <div class="fields">
        <label class="field">
          <span>Tempo source</span>
          <select
            :value="store.status.usesProjectTempo ? 1 : 0"
            :disabled="locked()"
            @change="setGlobalParam('tempo-select', Number(($event.target as HTMLSelectElement).value))"
          >
            <option :value="0">Bank tempo</option>
            <option :value="1">Project tempo</option>
          </select>
        </label>
        <label class="field">
          <span>Project tempo</span>
          <span class="tempo">
            <input
              class="mono"
              inputmode="decimal"
              :value="tempoValue('project-tempo', store.status.projectTempo)"
              :disabled="locked()"
              @input="tempoText['project-tempo'] = ($event.target as HTMLInputElement).value"
              @keydown.enter="($event.target as HTMLInputElement).blur()"
              @blur="commitTempo('project-tempo', store.status.projectTempo)"
            />
            BPM
          </span>
        </label>
      </div>
    </section>

    <section class="panel card clear">
      <div class="label">Clear project</div>
      <p class="muted hint">
        Removes what is ticked from project {{ store.status.project }} and keeps the rest. It
        cannot be undone: export what you want to keep first.
      </p>
      <label class="field scope">
        <span>From</span>
        <select v-model="parts.bank">
          <option :value="null">The whole project</option>
          <option v-for="(letter, i) in BANK_LETTERS" :key="letter" :value="i">Bank {{ letter }} only</option>
        </select>
      </label>
      <div class="parts">
        <label><input v-model="parts.samples" type="checkbox" :disabled="parts.settings" /> Samples</label>
        <label><input v-model="parts.patterns" type="checkbox" :disabled="parts.settings" /> Patterns</label>
        <label>
          <input v-model="parts.screenImages" type="checkbox" :disabled="parts.bank !== null" /> Screen images
          <span class="muted">startup and screen savers go back to the SP-404MKII's own</span>
        </label>
        <label>
          <input v-model="parts.settings" type="checkbox" :disabled="parts.bank !== null" /> Settings and name
          <span class="muted">tempos and bank settings; takes samples and patterns with them</span>
        </label>
      </div>
      <div class="confirm">
        <input
          v-model="confirmText"
          class="mono"
          inputmode="numeric"
          :placeholder="`Type ${store.status.project} to confirm`"
          :disabled="locked()"
        />
        <button class="danger" :disabled="!canClear" @click="onClear">Clear</button>
      </div>
    </section>

    <section class="panel card backup">
      <div class="label">Back up and restore</div>
      <p class="muted hint">
        A backup copies project {{ store.status.project }}'s whole folder to this computer: samples, patterns,
        settings and screen images, the same files the official app exports. Restoring one replaces everything in
        project {{ store.status.project }}.
      </p>
      <div class="backup-buttons">
        <button :disabled="store.pending > 0" @click="backupProject">Back up project {{ store.status.project }}…</button>
        <button class="danger" :disabled="store.pending > 0 || locked()" @click="restoreBackup">Restore a backup…</button>
      </div>
      <p v-if="store.transfer && store.pending > 0" class="muted progress">
        <span class="spinner" /> {{ store.transfer.name }} ({{ store.transfer.done + 1 }} of {{ store.transfer.total }})
      </p>
    </section>

    <section class="panel card">
      <div class="label">Device</div>
      <dl>
        <dt>Port</dt>
        <dd class="mono">{{ store.status.port }}</dd>
        <dt>Free space</dt>
        <dd class="mono">{{ storage(store.status.freeKb) }}</dd>
        <dt>Screen</dt>
        <dd>{{ store.status.workingMode === 4 ? "Menu open" : "Normal" }}</dd>
      </dl>
    </section>

    <section class="panel banks">
      <div class="label">Banks</div>
      <table>
        <thead>
          <tr>
            <th>Bank</th>
            <th>Tempo (BPM)</th>
            <th>Volume</th>
            <th>Protect</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="b in store.status.banks" :key="b.letter">
            <td class="letter">{{ b.letter }}</td>
            <td>
              <input
                class="mono bank-tempo"
                inputmode="decimal"
                :value="tempoValue(`bank-tempo-${b.letter.toLowerCase()}`, b.tempo)"
                :disabled="locked()"
                @input="tempoText[`bank-tempo-${b.letter.toLowerCase()}`] = ($event.target as HTMLInputElement).value"
                @keydown.enter="($event.target as HTMLInputElement).blur()"
                @blur="commitTempo(`bank-tempo-${b.letter.toLowerCase()}`, b.tempo)"
              />
            </td>
            <td>
              <div class="volume">
                <input
                  type="range"
                  min="0"
                  max="127"
                  :value="volumeDraft[`bank-volume-${b.letter.toLowerCase()}`] ?? b.volume"
                  :disabled="locked()"
                  @input="volumeDraft[`bank-volume-${b.letter.toLowerCase()}`] = Number(($event.target as HTMLInputElement).value)"
                  @change="commitVolume(b.letter, b.volume)"
                />
                <span class="mono">{{ volumeDraft[`bank-volume-${b.letter.toLowerCase()}`] ?? b.volume }}</span>
              </div>
            </td>
            <td>
              <label class="switch-row">
                <span class="switch">
                  <input
                    type="checkbox"
                    :checked="b.protected"
                    :disabled="locked()"
                    @change="setGlobalParam(`bank-protect-${b.letter.toLowerCase()}`, ($event.target as HTMLInputElement).checked ? 1 : 0)"
                  />
                  <span />
                </span>
                <Icon v-if="b.protected" name="lock" :size="13" />
              </label>
            </td>
          </tr>
        </tbody>
      </table>
    </section>

    <p class="note muted">Changes go to the SP-404MKII as soon as you make them.</p>

    <section class="panel app">
      <div class="label">App <span v-if="version" class="muted version">SparkyMK2 {{ version }}</span></div>
      <label class="pref">
        <span class="switch">
          <input v-model="store.prefs.preloadFolders" type="checkbox" @change="savePrefs" />
          <span />
        </span>
        <span>
          Preload sounds when a folder opens
          <span class="muted hint">
            Every sound in a folder is fetched as soon as it opens, in the Files tab and the
            Import browser, so browsing it plays each one at once. Opening a folder keeps the
            device busy for longer while it loads.
          </span>
        </span>
      </label>
      <label class="pref">
        <span class="switch">
          <input v-model="store.prefs.collectScreens" type="checkbox" @change="savePrefs" />
          <span />
        </span>
        <span>
          Keep every display image written to the device in the screen library
          <span class="muted hint">
            Each image applied in the Screens tab is saved to the library too, once, so it can go to other projects
            later.
          </span>
        </span>
      </label>
      <div class="pref library-dir">
        <span>
          Screen library folder
          <span class="muted hint">
            <span class="mono">{{ store.library.dir || "…" }}</span><br />
            A plain folder of PNGs: 128×64 for a frame, 128×384 for a set of six. Sync it or add images from other
            programs; the library reads it again when opened.
          </span>
        </span>
        <div class="dir-buttons">
          <button @click="chooseLibraryDir">Change…</button>
          <button v-if="store.prefs.libraryDir" @click="setLibraryDir('')">Use the default</button>
        </div>
      </div>
      <label class="pref">
        <span class="switch">
          <input
            :checked="logState?.enabled ?? false"
            :disabled="!logState"
            type="checkbox"
            @change="toggleLogging(($event.target as HTMLInputElement).checked)"
          />
          <span />
        </span>
        <span>
          Write a diagnostic log
          <span class="muted hint">
            Records everything the app does and how the SP-404MKII answers, to send in with a bug report. It stays on
            until you turn it off, and each start of the app begins a new file; the last 10 are kept.
          </span>
        </span>
      </label>
      <div class="pref library-dir">
        <span>
          Log folder
          <span class="muted hint">
            <span class="mono">{{ logState?.file ?? logState?.folder ?? "…" }}</span>
            <span v-if="logError" class="log-error"><br />{{ logError }}</span>
          </span>
        </span>
        <div class="dir-buttons">
          <button @click="openLogFolder">Open log folder</button>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
.clear .parts {
  display: grid;
  gap: 6px;
  margin: 10px 0;
}

/* Each option's name stays on one line; its note wraps beside it. */
.clear .parts label {
  display: flex;
  gap: 8px;
  align-items: baseline;
  white-space: nowrap;
}

.clear .parts .muted {
  font-size: 12px;
  white-space: normal;
}

.clear .confirm {
  display: flex;
  gap: 8px;
}

.clear .confirm input {
  width: 16ch;
}

.version {
  margin-left: 6px;
  text-transform: none;
  letter-spacing: 0;
}

.settings {
  height: 100%;
  overflow: auto;
  padding: 14px;
  display: grid;
  /* Two columns, or three on a wide window; Banks and App span them all. */
  grid-template-columns: repeat(auto-fill, minmax(430px, 1fr));
  grid-auto-rows: min-content;
  gap: 14px;
  align-content: start;
  max-width: 1480px;
}

.card,
.banks {
  padding: 16px;
}

.banks,
.app {
  grid-column: 1 / -1;
}

.app {
  padding: 16px;
}

.pref {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  margin-top: 10px;
  cursor: pointer;
}

.scope {
  margin: 8px 0 2px;
}

.backup-buttons {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-top: 10px;
}

.progress {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 10px 0 0;
  font-size: 12px;
}

.library-dir {
  cursor: default;
  justify-content: space-between;
}

.log-error {
  color: var(--danger, #e5534b);
}

.dir-buttons {
  display: flex;
  gap: 8px;
  flex: none;
}

.pref .hint {
  display: block;
  margin-top: 3px;
  font-size: 12.5px;
  max-width: 640px;
}

.project {
  display: flex;
  align-items: baseline;
  gap: 12px;
  margin: 8px 0 12px;
  min-width: 0;
}

.num {
  font-size: 22px;
  color: var(--accent);
  font-weight: 600;
}

.pname {
  font-size: 18px;
  font-weight: 600;
}

.fields {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.field {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  color: var(--muted);
}

.field select,
.field input {
  color: var(--text);
}

.tempo {
  display: flex;
  align-items: center;
  gap: 6px;
}

.tempo input,
.bank-tempo {
  width: 84px;
  text-align: right;
}

dl {
  margin: 10px 0 0;
  display: grid;
  grid-template-columns: 140px 1fr;
  row-gap: 6px;
}

dt {
  color: var(--muted);
}

dd {
  margin: 0;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}

th {
  text-align: left;
  font-weight: 500;
  color: var(--muted);
  font-size: 12px;
  padding: 6px 10px;
  border-bottom: 1px solid var(--line);
}

td {
  padding: 5px 10px;
  border-bottom: 1px solid var(--line);
}

tr:last-child td {
  border-bottom: none;
}

.letter {
  font-weight: 650;
}

.volume {
  display: flex;
  align-items: center;
  gap: 10px;
}

.volume input {
  width: 200px;
}

.volume span {
  width: 28px;
  text-align: right;
}

.switch-row {
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--accent);
}

.note {
  grid-column: 1 / -1;
  margin: 0;
  font-size: 12.5px;
}
</style>
